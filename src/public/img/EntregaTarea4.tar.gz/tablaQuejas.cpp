#include "../include/tablaQuejas.h"

struct nodoQueja {
  TQueja queja;
  nodoQueja * sig;
};

struct rep_tablaQuejas { 
  nodoQueja ** tabla;
  int cantEstimadas;
};

int funcionHash(TFecha fecha, int cantEstimadas){
    return (31 * (int) mesTFecha(fecha) + (int) diaTFecha(fecha)) % cantEstimadas;
}

TablaQuejas crearTablaQuejas(int cantEstimadas) { 
  TablaQuejas newTabla = new rep_tablaQuejas;
  newTabla -> cantEstimadas = cantEstimadas;
  newTabla -> tabla = new nodoQueja* [cantEstimadas];
  for(int i = 0; i < cantEstimadas; i++){
    newTabla -> tabla[i] = NULL;
  };
  return newTabla;
}

void agregarQuejaTablaQuejas(TablaQuejas tabla, TQueja queja) { 
  nodoQueja *agregarQueja = new nodoQueja;
  agregarQueja -> queja = queja;
  agregarQueja -> sig = tabla -> tabla[funcionHash(fechaTQueja(queja), tabla -> cantEstimadas)];
  tabla -> tabla[funcionHash(fechaTQueja(queja), tabla -> cantEstimadas)] = agregarQueja;
}

void imprimirTablaQuejas(TablaQuejas tabla) { 
  for(int i = 0; i < tabla -> cantEstimadas; i++){
    if(tabla -> tabla[i] == NULL){
      printf("No hay elementos guardados en la posicion %d de la tabla.\n", i);
    }else{
      printf("Elementos en la posicion %d de la tabla:\n", i);
      nodoQueja *aux = tabla -> tabla[i];
      while(aux != NULL){
        imprimirTQueja(aux -> queja);
        aux = aux -> sig;
      };
    }
  }
}

bool perteneceQuejaTablaQuejas(TablaQuejas tabla, TFecha fecha) {
  if(tabla -> tabla[funcionHash(fecha, tabla -> cantEstimadas)] != NULL){
    nodoQueja *aux = tabla -> tabla[funcionHash(fecha, tabla -> cantEstimadas)];
    while(aux != NULL && (compararTFechas(fechaTQueja(aux -> queja), fecha)) != 0){
      aux = aux -> sig;
    };
    return aux != NULL;
  }
  return false;
}

TQueja obtenerQuejaTablaQuejas(TablaQuejas tabla, TFecha fecha) {
  if(tabla -> tabla[funcionHash(fecha, tabla -> cantEstimadas)] != NULL){
    nodoQueja *aux = tabla -> tabla[funcionHash(fecha, tabla -> cantEstimadas)];
    while(aux != NULL && (compararTFechas(fechaTQueja(aux -> queja), fecha)) != 0){
      aux = aux -> sig;
    };
    if(aux == NULL){
      return NULL;
    }else{
      return aux -> queja;
    }
  }
  return NULL;
}

void liberarTablaQuejas(TablaQuejas &tabla) {
  for (int i=0; i < tabla->cantEstimadas; i++) {
        nodoQueja *aux = tabla->tabla[i];
        
        while (aux != NULL) {
            nodoQueja *aux2 = aux;
            aux = aux->sig;
            liberarTQueja(aux2 -> queja);
            delete aux2;
        }
    }
    
    delete[] tabla->tabla;
    delete tabla;
    tabla = NULL;
}
