#include "../include/colaEnvios.h"

struct rep_cola_envios {
    TEnvio *envios;
    int max;
    int cantidad;
};

TColaEnvios crearTColaEnvios(int N) { 
    TColaEnvios newColaEnvios = new rep_cola_envios;
    newColaEnvios -> max = N;
    newColaEnvios -> cantidad = 0;
    newColaEnvios -> envios = new TEnvio[N];
    for(int i = 0; i < N; i++){
        newColaEnvios -> envios[i] = NULL;
    };
    return newColaEnvios;
}

void encolarEnvioTColaEnvios(TColaEnvios &colaEnvios, TEnvio envio) {
    if(colaEnvios != NULL && (colaEnvios -> max != colaEnvios -> cantidad)){
        int indice = 0;
        while((indice < colaEnvios -> cantidad) && (compararTFechas(obtenerFechaTEnvio(colaEnvios -> envios[indice]), obtenerFechaTEnvio(envio)) == -1)){
            indice++;
        };
        for (int i = colaEnvios->cantidad - 1; i >= indice; i--) {
            colaEnvios->envios[i + 1] = colaEnvios->envios[i];
        }
        colaEnvios->envios[indice] = envio;
        colaEnvios->cantidad++;
    }
}

int cantidadTColaEnvios(TColaEnvios colaEnvios) { 
    if(colaEnvios != NULL){
        return colaEnvios -> cantidad;
    }else{
        return 0;
    };
}

void imprimirTColaEnvios(TColaEnvios colaEnvios) {
    if(colaEnvios != NULL){
        for(int i = 0; i < colaEnvios -> cantidad; i++){
            printf("Nivel %d:\n", i+1);
            imprimirTEnvio(colaEnvios -> envios[i]);
        };
    }
}

TEnvio desencolarTColaEnvios(TColaEnvios &colaEnvios) { 
    TEnvio envioRemovido = colaEnvios -> envios[colaEnvios -> cantidad - 1];
    colaEnvios -> envios[colaEnvios -> cantidad - 1] = NULL;
    colaEnvios -> cantidad--;
    return envioRemovido;
}

void liberarTColaEnvios(TColaEnvios &colaEnvios) {
  if(colaEnvios != NULL){
    for(int i = 0; i < colaEnvios -> cantidad; i++){
        liberarTEnvio(colaEnvios -> envios[i]);
    };
    delete[] colaEnvios->envios;
    delete colaEnvios;
    colaEnvios = NULL;
  }
}

void invertirPrioridadTColaEnvios(TColaEnvios &colaEnvio) {
    if (colaEnvio != NULL && colaEnvio -> cantidad > 1) {
        int fin = colaEnvio -> cantidad - 1;
        for (int i=0; i < (fin + 1) / 2; i++) {
            TEnvio aux = colaEnvio -> envios[i];
            colaEnvio -> envios[i] = colaEnvio -> envios[fin - i];
            colaEnvio -> envios[fin - i] = aux;
        }
    }
}

TEnvio masPrioritarioTColaEnvios(TColaEnvios colaEnvio) { 
    return colaEnvio -> envios[(colaEnvio -> cantidad) - 1]; 
}

int maxTColaEnvios(TColaEnvios colaEnvio) { 
    return colaEnvio -> max; 
}