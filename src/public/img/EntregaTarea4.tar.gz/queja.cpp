#include "../include/queja.h"

struct rep_queja {
  TCliente cliente;
  TProducto producto; 
  TFecha fecha;
  char comentario[MAX_COMENTARIO];
};

TQueja crearTQueja(TFecha fecha, TProducto producto, TCliente cliente, const char comentario[MAX_COMENTARIO]) {
  TQueja newQueja = new rep_queja;
  newQueja -> cliente = cliente;
  newQueja -> producto = producto;
  newQueja -> fecha = fecha;
  strcpy(newQueja -> comentario , comentario);
  return newQueja;
}

void imprimirTQueja(TQueja queja) { 
  printf("Fecha: ");
  imprimirTFecha(queja -> fecha);
  printf("\n");
  printf("Cliente: ");
  imprimirTCliente(queja -> cliente);
  imprimirTProducto(queja -> producto);
  printf("\n");
  printf("Comentario: %s\n", queja -> comentario);
}

void liberarTQueja(TQueja &queja) { 
  liberarTProducto(queja -> producto);
  liberarTFecha(queja -> fecha);
  liberarTCliente(queja -> cliente);
  delete queja;
  queja = NULL;
}

TFecha fechaTQueja(TQueja queja) { 
  return queja -> fecha; 
}
